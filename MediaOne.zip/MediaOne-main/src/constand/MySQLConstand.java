package constand;

/**
 * @author nguyen
 * @create_date 29/04/2022
 */
public interface MySQLConstand {

  String URL = "jdbc:mysql://localhost:3306/open-shop?useSSL=false";
  String USER_NAME = "root";
  String PASSWORD = "NmIT.432";
  String CLASS_NAME = "com.mysql.cj.jdbc.Driver";
}
