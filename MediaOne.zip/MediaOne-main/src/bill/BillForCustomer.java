/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bill;

import Product.Product;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import person.Customer;

/**
 *
 * @author nnminh322
 */
//Kế thừa Customer, xuất thông tin customer kèm theo bill
public class BillForCustomer extends Customer implements Serializable{

    //Các thuộc tính:
    private String idBill;
    private Date date;
    public Float sumOfBill; //Phương thức tính tổng ông làm giúp tôi với, tôi làm mà nó bị lỗi
    private Customer customer;
    private List<Product> listProduct;
    
    //Đoạn dưới này là các thủ tục thôi, không có gì đáng kể.

    public BillForCustomer(String idBill, Date date, Float sumOfBill, Customer customer, List<Product> listProduct) {
        this.idBill = idBill;
        this.date = date;
        this.sumOfBill = sumOfBill;
        this.customer = customer;
        this.listProduct = listProduct;
    }

    public String getIdBill() {
        return idBill;
    }

    public void setIdBill(String idBill) {
        this.idBill = idBill;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Float getSumOfBill() {
        return sumOfBill;
    }

    public void setSumOfBill(Float sumOfBill) {
        this.sumOfBill = sumOfBill;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Product> getListProduct() {
        return listProduct;
    }

    public void setListProduct(List<Product> listProduct) {
        this.listProduct = listProduct;
    }
    

}