/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

/**
 *
 * @author nnminh322
 */
import Product.Product;
import database.DB;
import java.util.List;
import mediaone.MediaOne;
import bill.BillForCustomer;
import bill.BillForEmployee;
public class BillController {
    private MediaOne mediaOne;
    private DB db;
    private BillForCustomer billForCustomer;
    private BillForEmployee billForEmployee;

    public BillController(MediaOne mediaOne, DB db, BillForCustomer billForCustomer, BillForEmployee billForEmployee) {
        this.mediaOne = mediaOne;
        this.db = db;
        this.billForCustomer = billForCustomer;
        this.billForEmployee = billForEmployee;
    }

    public MediaOne getMediaOne() {
        return mediaOne;
    }

    public void setMediaOne(MediaOne mediaOne) {
        this.mediaOne = mediaOne;
    }

    public DB getDb() {
        return db;
    }

    public void setDb(DB db) {
        this.db = db;
    }

    public BillForCustomer getBillForCustomer() {
        return billForCustomer;
    }

    public void setBillForCustomer(BillForCustomer billForCustomer) {
        this.billForCustomer = billForCustomer;
    }

    public BillForEmployee getBillForEmployee() {
        return billForEmployee;
    }

    public void setBillForEmployee(BillForEmployee billForEmployee) {
        this.billForEmployee = billForEmployee;
    }
    
    
    
    public List<Product> getListProduct(){
        return mediaOne.getListProduct();
    }
    
    //Phần dưới này còn cần các phương thức trên view: In hoá đơn cho khách và in hoá đơn cho nhân viên. Ông giúp tôi với
}
