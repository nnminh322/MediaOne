/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bill;

/**
 *
 * @author nnminh322
 */
import java.sql.Time;
import java.util.Date;
import person.Employee;
//Kế thừa employee, xuất thông tin employee và tổng tiền
public class BillForEmployee extends Employee {
    public Employee employee;
    public Float sumOfBill;
    
    public BillForEmployee(Employee employee, Float SumOfBill){
        this.employee = employee;
        this.sumOfBill = SumOfBill;
    }
    
    public BillForEmployee(){
        employee = new Employee();
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Float getSumOfBill() {
        return sumOfBill;
    }

    public void setSumOfBill(Float sumOfBill) {
        this.sumOfBill = sumOfBill;
    }

}
